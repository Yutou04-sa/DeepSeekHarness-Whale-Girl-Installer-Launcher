window.__ModuleLoader__.load({ id: "dsh-power-button", factory: (require) => {
var module = { exports: {} }; var exports = module.exports;
'use strict'

/**
 * dsh-power-button client half: a floating power button pinned to the
 * window's bottom-right corner. Primary click restarts DeepSeek Harness
 * (stop + start in one click); a small secondary action stops it without
 * relaunching. A status dot polls /dsh-power/health every 5 seconds.
 * Hand-authored CJS bundle — no build step; the only external is the loader
 * module table's `react`.
 */

const React = require('react')
const h = React.createElement
const { useState, useEffect, useRef } = React

const NS = 'dsh-power-button'

const HEALTH_URL = '/dsh-power/health'
const RESTART_URL = '/dsh-power/restart'
const STOP_URL = '/dsh-power/stop'

const CSS = `
.dshp-root {
  position: fixed;
  right: 18px;
  bottom: 18px;
  display: flex;
  align-items: flex-end;
  flex-direction: column;
  gap: 8px;
  z-index: 2147483000;
  pointer-events: none;
}
.dshp-btn {
  pointer-events: auto;
  border: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
  transition: transform 0.12s ease, background 0.15s ease;
  font-family: inherit;
}
.dshp-btn:hover { transform: scale(1.07); }
.dshp-btn:active { transform: scale(0.96); }
.dshp-btn:disabled { cursor: default; opacity: 0.85; }
.dshp-main {
  width: 54px;
  height: 54px;
  background: #1f6feb;
  color: #fff;
  position: relative;
}
.dshp-main.dshp-busy { background: #b45309; animation: dshp-pulse 1.2s ease-in-out infinite; }
.dshp-main.dshp-down { background: #b91c1c; }
.dshp-stop {
  width: 38px;
  height: 38px;
  background: #dc2626;
  color: #fff;
  font-size: 16px;
  line-height: 1;
}
.dshp-dot {
  position: absolute;
  top: 3px;
  right: 3px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid #fff;
  background: #22c55e;
}
.dshp-dot.dshp-down { background: #ef4444; }
.dshp-dot.dshp-busy { background: #f59e0b; }
.dshp-label {
  pointer-events: auto;
  background: rgba(17, 24, 39, 0.82);
  color: #fff;
  font-size: 12px;
  line-height: 1.4;
  padding: 6px 10px;
  border-radius: 8px;
  max-width: 220px;
  text-align: right;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
}
@keyframes dshp-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(180, 83, 9, 0.5), 0 4px 14px rgba(0, 0, 0, 0.35); }
  50% { box-shadow: 0 0 0 12px rgba(180, 83, 9, 0), 0 4px 14px rgba(0, 0, 0, 0.35); }
}
`

function injectStyles() {
  if (document.querySelector('style[data-plugin-css="dsh-power-button/fab"]') !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = NS
  tag.dataset.pluginCss = 'dsh-power-button/fab'
  tag.textContent = CSS
  document.head.appendChild(tag)
}

exports.name = NS
exports.inject = ['slots']
exports.apply = function apply(ctx) {
  function PowerFab() {
    // phase: 'idle' | 'restarting' | 'stopping'
    const [phase, setPhase] = useState('idle')
    // alive: harness health endpoint reachable
    const [alive, setAlive] = useState(true)
    const [label, setLabel] = useState(null)
    const phaseRef = useRef('idle')
    const timerRef = useRef(null)

    const setPhaseBoth = (next) => {
      phaseRef.current = next
      setPhase(next)
    }

    const poll = async () => {
      let ok = false
      try {
        const res = await fetch(HEALTH_URL, { headers: { accept: 'application/json' } })
        ok = res.ok
      } catch { ok = false }
      setAlive(ok)
      // After a restart the old page's fetch briefly fails; once the new
      // harness answers health, reload so the UI reconnects to the new host.
      if (phaseRef.current === 'restarting' && ok) {
        window.location.reload()
      }
    }

    useEffect(() => {
      injectStyles()
      poll()
      const timer = setInterval(poll, 5000)
      timerRef.current = timer
      return () => clearInterval(timer)
    }, [])

    const doRestart = async () => {
      if (phaseRef.current !== 'idle') return
      setPhaseBoth('restarting')
      setLabel('正在重启 DeepSeek Harness…')
      try {
        await fetch(RESTART_URL, { method: 'POST', headers: { accept: 'application/json' } })
      } catch { /* the host may die before the response lands */ }
      // Safety: if the new host never comes up, restore the idle state so the
      // button can be pressed again (e.g. to retry after a manual restart).
      setTimeout(() => {
        if (phaseRef.current === 'restarting') {
          setPhaseBoth('idle')
          setLabel('重启超时，Harness 未恢复，可重试')
        }
      }, 60000)
    }

    const doStop = async () => {
      if (phaseRef.current !== 'idle') return
      setPhaseBoth('stopping')
      setLabel('正在停止 DeepSeek Harness…（之后需手动启动）')
      try {
        await fetch(STOP_URL, { method: 'POST', headers: { accept: 'application/json' } })
      } catch { /* host dies before the response lands */ }
    }

    const busy = phase !== 'idle'
    const down = !alive && !busy
    const cls = busy ? 'dshp-btn dshp-main dshp-busy' : (down ? 'dshp-btn dshp-main dshp-down' : 'dshp-btn dshp-main')
    const dotCls = busy ? 'dshp-dot dshp-busy' : (down ? 'dshp-dot dshp-down' : 'dshp-dot')

    return h('div', { className: 'dshp-root' },
      label !== null ? h('div', { className: 'dshp-label' }, label) : null,
      h('button', {
        className: 'dshp-btn dshp-stop',
        title: '仅停止（不自动重启）',
        disabled: busy,
        onClick: () => void doStop(),
      }, '⏻'),
      h('button', {
        className: cls,
        title: busy
          ? (phase === 'restarting' ? '正在重启…' : '正在停止…')
          : '一键启停 DeepSeek Harness（重启）',
        disabled: busy,
        onClick: () => void doRestart(),
      },
        h('svg', {
          width: '24', height: '24', viewBox: '0 0 24 24',
          fill: 'none', stroke: 'currentColor', strokeWidth: '2',
          strokeLinecap: 'round', strokeLinejoin: 'round',
        },
          h('path', { d: 'M18.36 6.64a9 9 0 1 1-12.73 0' }),
          h('line', { x1: '12', y1: '2', x2: '12', y2: '12' })),
        h('span', { className: dotCls })))
  }

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'dsh-power-button-fab',
    order: 1000,
    label: () => 'DSH 启停',
  }, PowerFab))
}

return module.exports; } });

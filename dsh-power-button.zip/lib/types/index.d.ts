/** One-click start/stop (restart) button for DeepSeek Harness (bundle plugin). */
export declare const name: 'dsh-power-button'
export declare function apply(ctx: unknown, config?: unknown): void
